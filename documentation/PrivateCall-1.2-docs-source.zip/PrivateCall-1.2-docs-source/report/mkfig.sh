#!/bin/sh
# usage: mkfig.sh name  -> /tmp/fig-name-1.png
cd /home/claude/docbuild/report
xelatex -interaction=nonstopmode -jobname=fig-$1 "\def\fig{$1}\input{figtest}" > /tmp/figlog-$1.txt 2>&1
grep -E "^!" -A3 /tmp/figlog-$1.txt | head -12
pdftoppm -r 120 -png fig-$1.pdf /tmp/fig-$1
