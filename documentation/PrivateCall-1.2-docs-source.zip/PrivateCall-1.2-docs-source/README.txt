PrivateCall 1.2 - documentation sources
=======================================

report/
  report.tex          Main LaTeX source of PrivateCall-System-Report.pdf
  results-table.tex   Table 7 (test results of the rerun), included by report.tex
  figures/*.tex       TikZ sources of Figures 1-7
  fig-*.pdf           Compiled figures (used by report.tex)
  figtest.tex         Wrapper used to compile one figure on its own
  mkfig.sh            Compiles one figure:  ./mkfig.sh <name>
  code/               Unmodified copies of the PrivateCall 1.2 source files.
                      The code listings in the report are read from these
                      files by line number (\lstinputlisting), so every
                      listing is a verbatim excerpt.

howto/
  howto.tex                 LaTeX source of PrivateCall-How-To.pdf
  PrivateCall-How-To.txt    Plain-text version of the user guide

Building (TeX Live with XeLaTeX; fonts: TeX Gyre Pagella, Liberation Sans,
DejaVu Sans Mono):
  cd report
  for f in architecture sequence paths auth gating states envelope; do ./mkfig.sh $f; done
  xelatex report.tex && xelatex report.tex
  cd ../howto && xelatex howto.tex && xelatex howto.tex

mkfig.sh expects to run from /home/claude/docbuild/report; adjust the cd
line in it for another location. The figure PDFs are named fig-<name>.pdf
and must sit next to report.tex.
